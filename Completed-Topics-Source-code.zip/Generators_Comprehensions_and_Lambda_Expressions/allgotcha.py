entries = [1, 2, 3, 4, 5]
 
print("all: {}".format(all(entries)))
print("any: {}".format(any(entries)))